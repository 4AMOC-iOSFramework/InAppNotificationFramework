//
//  ViewController.swift
//  Example
//
//  Created by Henri Gil on 04/02/2018.
//  Copyright © 2018 Henri Gil. All rights reserved.
//

import UIKit
import InAppNotificationFramework

class ViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(white: 0.1, alpha: 1)
        
        //Getting callback notif
         NotificationCenter.default.addObserver(self, selector: #selector(notificationsHandler), name: Notification.Name("notificationTapped") , object: nil)

        /*Buttons*/
        let button_urlImage = initialzeButton(title: "Add 1 notification: Url image anim: left")
        button_urlImage.addTarget(self, action: #selector(addNotif), for: .touchUpInside)
        view.addSubview(button_urlImage)

        let button_arrayNotif = initialzeButton(title: "Add a notification array: Url image")
        button_arrayNotif.addTarget(self, action: #selector(addNotifs), for: .touchUpInside)
        view.addSubview(button_arrayNotif)

        let button_localImage = initialzeButton(title: "Add a notification: Local image")
        button_localImage.addTarget(self, action: #selector(addNotifLocal), for: .touchUpInside)
        view.addSubview(button_localImage)

        let button_Timer = initialzeButton(title: "Add a notification: Timer 5sec")
        button_Timer.addTarget(self, action: #selector(addNotifSecond), for: .touchUpInside)
        view.addSubview(button_Timer)

        /*Layout*/
        NSLayoutConstraint.activate([
            button_urlImage.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button_urlImage.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            button_urlImage.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            button_urlImage.heightAnchor.constraint(lessThanOrEqualToConstant: 100),
            
            button_arrayNotif.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button_arrayNotif.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 50),
            button_arrayNotif.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            button_arrayNotif.heightAnchor.constraint(lessThanOrEqualToConstant: 100),
            
            button_localImage.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button_localImage.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0),
            button_localImage.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            button_localImage.heightAnchor.constraint(lessThanOrEqualToConstant: 100),
            
            button_Timer.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button_Timer.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 100),
            button_Timer.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            button_Timer.heightAnchor.constraint(lessThanOrEqualToConstant: 100),
            ])
    }

    @objc func addNotifSecond(){
        let notif1 = NotificationData()
        notif1.id = "id4342"
        notif1.delay = 5
        notif1.title = "New message from Henri GIL"
        notif1.message = "Le Lorem Ipsum est simplement du faux texte employé dans la"
        notif1.thumbnailUrl = "thumb"
        notif1.contentImage = "rotortrade_logo4"
        notif1.animationStyle = .top
        
        InAppNotification.shared.addNotification(notification: notif1)
        
    }
    
    @objc func addNotifLocal(){
        let notif1 = NotificationData()
        notif1.id = "id4342"
        notif1.title = "New message from Jean"
        notif1.message = "Le Lorem Ipsum est simplement du faux texte employé dans la"
        notif1.thumbnailUrl = "thumb"
        notif1.contentImage = "rotortrade_logo4"
        notif1.animationStyle = .top
        
        InAppNotification.shared.addNotification(notification: notif1)
    }
    
    @objc func addNotif(){
        
        let notif1 = NotificationData()
        notif1.id = "id4342"
        notif1.animationStyle = .left
        notif1.title = "New message from Claude"
        notif1.message = "Le Lorem Ipsum est simplement du faux texte employé dans la"
        notif1.thumbnailUrl = "thumb"
        notif1.contentImage = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Google_Images_2015_logo.svg/1200px-Google_Images_2015_logo.svg.png"
        
        InAppNotification.shared.addNotification(notification: notif1)
    }
    
    @objc func addNotifs(){
        
        let notif1 = NotificationData()
        notif1.id = "id4342"
        notif1.title = "New message from Biloute"
        notif1.message = "Le Lorem Ipsum est simplement du faux texte employé dans la"
        notif1.thumbnailUrl = "thumb"
        notif1.contentImage = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Google_Images_2015_logo.svg/1200px-Google_Images_2015_logo.svg.png"
        notif1.animationStyle = .top
        
        let notif2 = NotificationData()
        notif2.id = "id4344"
        notif2.title = "New message from hGxL"
        notif2.message = "Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le. Le Lorem Ipsum est simplement du faux texte employé"
        notif2.thumbnailUrl = "thumb"
        notif2.contentImage = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Google_Images_2015_logo.svg/1200px-Google_Images_2015_logo.svg.png"
        notif2.animationStyle = .top
        
        let notif3 = NotificationData()
        notif3.id = "id4349"
        notif3.title = "New message from Louis"
        notif3.message = "Le Lorem Ipsum est simplement du faux texte employé dans la"
        notif3.thumbnailUrl = "thumb"
        notif3.animationStyle = .top
        
        InAppNotification.shared.addNotifications(notifications: [notif1,notif2, notif3])
    }
    
    @objc func notificationsHandler(notif: Notification) {
        
        if let notification = notif.object as? NotificationData {
            print(notification)
            let alert = UIAlertController(title: "CallBack", message: "Click on notification id = \(notification.id)", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Continue", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func initialzeButton(title: String) -> UIButton {
        let but = UIButton()
        but.translatesAutoresizingMaskIntoConstraints=false
        but.backgroundColor = .clear
        but.setTitle(title, for: .normal)
        return but
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

